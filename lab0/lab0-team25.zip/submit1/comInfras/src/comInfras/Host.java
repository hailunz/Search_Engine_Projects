package comInfras;


/*
 * 18842 lab0
 * team 32
 * Hailun Zhu, ID: hailunz; 
 */
public class Host {
	public String name;
	public String ip;
	public int port;
}
