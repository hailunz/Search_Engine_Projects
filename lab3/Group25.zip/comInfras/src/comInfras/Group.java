package comInfras;

import java.util.List;

public class Group {
	public String name;
	public List<String> members;
}
